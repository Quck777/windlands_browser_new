<?php
include "quests.php"; 
?>